#!/bin/bash
SUPPORT="$HOME/Library/Application Support"
ACTIVE="$SUPPORT/Claude"
STORE="$SUPPORT/Claude-Profiles"
MARK=".switcher-profile"
TITLE="Switch Account for Claude"
mkdir -p "$STORE"

note()  { osascript -e "display notification \"$1\" with title \"$TITLE\"" >/dev/null 2>&1; }
alert() { osascript -e "display alert \"$TITLE\" message \"$1\"" >/dev/null 2>&1; }

# Detect the active account from the profile tag
current=""
[ -f "$ACTIVE/$MARK" ] && current=$(cat "$ACTIVE/$MARK")
if [ -z "$current" ] && [ -d "$ACTIVE" ]; then
  # Untagged: if a saved Work profile exists, this must be Personal (and vice versa); else ask once
  if   [ -d "$STORE/Work" ];     then current="Personal"
  elif [ -d "$STORE/Personal" ]; then current="Work"
  else
    current=$(osascript -e 'choose from list {"Work","Personal"} with title "Switch Account for Claude" with prompt "Which account is Claude signed into right now?" default items {"Work"}')
    [ "$current" = "false" ] || [ -z "$current" ] && exit 0
  fi
  echo "$current" > "$ACTIVE/$MARK"
fi
[ -z "$current" ] && current="Personal"

if [ "$current" = "Work" ]; then target="Personal"; else target="Work"; fi

# Quit Claude if it's running
if pgrep -x Claude >/dev/null; then
  osascript -e 'tell application "Claude" to quit' >/dev/null 2>&1
  for i in $(seq 1 40); do pgrep -x Claude >/dev/null || break; sleep 0.5; done
  if pgrep -x Claude >/dev/null; then alert "Claude didn't quit. Close it and try again."; exit 1; fi
fi

if [ -e "$STORE/$current" ]; then
  alert "A saved '$current' profile already exists in Claude-Profiles. Nothing was changed."; exit 1
fi

# Swap folders
[ -d "$ACTIVE" ] && mv "$ACTIVE" "$STORE/$current"
if [ -d "$STORE/$target" ]; then
  mv "$STORE/$target" "$ACTIVE"
  note "Switched to $target"
else
  mkdir -p "$ACTIVE"; echo "$target" > "$ACTIVE/$MARK"
  alert "First time on $target: sign in with your $target account when Claude opens."
fi

open -a Claude
